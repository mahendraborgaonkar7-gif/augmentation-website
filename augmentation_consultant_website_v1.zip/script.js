const menuToggle = document.querySelector('.menu-toggle');
const nav = document.querySelector('.nav');
if (menuToggle) {
  menuToggle.addEventListener('click', () => nav.classList.toggle('open'));
}
document.querySelectorAll('.nav a').forEach(a => {
  a.addEventListener('click', () => nav.classList.remove('open'));
});
function handleSubmit(e){
  e.preventDefault();
  const msg = document.getElementById('form-message');
  msg.textContent = 'Thank you. Your requirement has been captured. Connect this form to your business email/CRM before launch.';
  e.target.reset();
  return false;
}
